# REST API Explorer

A beginner-friendly Postman project for practising REST API basics using the public JSONPlaceholder testing API.

## What this project demonstrates

- Sending a `GET` request to retrieve one resource.
- Sending a `GET` request to retrieve a collection of resources.
- Filtering resources with a query parameter.
- Sending a `POST` request with a JSON request body.
- Sending a `DELETE` request for a resource.

## Tools and API

- **Postman** — to send and inspect API requests and responses.
- **JSONPlaceholder** — a public fake REST API for learning and testing: https://jsonplaceholder.typicode.com/

## Requests in the collection

| Request | Method | Endpoint | What it demonstrates |
|---|---|---|---|
| Get single post | `GET` | `/posts/1` | Retrieve one post by its ID |
| Get All Posts | `GET` | `/posts` | Retrieve the posts collection |
| Filters Posts by User | `GET` | `/posts?userId=2` | Filter posts using a query parameter |
| Create New Post | `POST` | `/posts` | Send JSON data in the request body |
| Delete Post | `DELETE` | `/posts/1` | Practise a delete request |

## How to import into Postman

1. Open Postman.
2. Choose **Import**.
3. Select `REST-API-Explorer.postman_collection.json` from this project folder.
4. Open the imported **REST API EXPLORER** collection.
5. Open any request and click **Send** to run it.

## Important learning notes

- `GET` is used to retrieve data.
- `POST` sends data to create a resource.
- `DELETE` requests deletion of a resource.
- A URL path such as `/posts/1` identifies a specific post.
- A query parameter such as `?userId=2` filters the results.
- JSON is the data format shown in the response and used in the POST request body.
- The HTTP response status helps indicate the outcome of a request (for example, `200 OK` or `201 Created`).

## Note about JSONPlaceholder

JSONPlaceholder is a fake online REST API intended for testing and learning. Its `POST` and `DELETE` endpoints simulate write operations and do not permanently modify a real production database.

## What I learned

- How a client (Postman) sends an HTTP request to a web API.
- How to inspect a JSON response.
- The difference between retrieving one resource and retrieving a collection.
- How query parameters filter results.
- How POST request bodies and DELETE requests work.

## Next steps

- Practise `PUT` and `PATCH` requests.
- Explore request headers and HTTP status codes.
- Add Postman test scripts and environment variables.
- Build a similar REST API using Python and FastAPI.

---

Beginner learning project — built while learning REST APIs and Postman.
